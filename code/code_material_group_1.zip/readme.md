# steps run the code

1 come into the directory in cmd

2 type python manage.py runserver

3 copy the link and paste it into the browser